# Fuel Route Optimizer

A Django + Django REST Framework service that plans a driving route between two
locations and recommends the cheapest fuel stops along the way, given a
vehicle's fuel economy, tank capacity and current fuel level.

## Features

- Geocoding of addresses or direct `lat,lon` coordinates.
- Route calculation through the OpenRouteService directions API.
- Matching of fuel stations from a local CSV to the route corridor.
- Cost-minimizing fuel-stop optimization with range constraints.
- JSON API with request validation and error handling.
- Unit tests for the fuel math, optimizer, routing client and API.

## Project layout

```
fuelrouteoptimizer/
├── manage.py
├── requirements.txt
├── .env / .env.example
├── config/                 # Django project (settings, urls, wsgi/asgi)
├── fuel_optimizer/
│   ├── api/                # serializers, views, urls
│   ├── services/           # routing, geocoding, stations, optimization
│   └── tests/
├── data/                   # fuel station CSVs
└── scripts/                # geocoding utility
```

## Getting started

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env      # then edit values
python manage.py migrate
python manage.py runserver
```

Set `ORS_API_KEY` in `.env` to a key from
<https://openrouteservice.org/dev/#/signup>. Without it, geocoding falls back to
Nominatim, but route calculation requires the key.

## API

### `POST /api/route/`

Request body:

```json
{
  "start": "Newark, NJ",
  "finish": "Chicago, IL",
  "mpg": 25,
  "tank_capacity_gallons": 50,
  "initial_fuel_gallons": 50,
  "corridor_miles": 5
}
```

Only `start` and `finish` are required; the remaining fields default to the
values in `.env`. `start` and `finish` may also be `"lat,lon"` strings.

Response (abridged):

```json
{
  "start": {
    "query": "Newark, NJ",
    "label": "...",
    "latitude": 40.73,
    "longitude": -74.17
  },
  "finish": {
    "query": "Chicago, IL",
    "label": "...",
    "latitude": 41.87,
    "longitude": -87.62
  },
  "route": {
    "distance_miles": 711.2,
    "duration_hours": 10.8,
    "geometry": [],
    "bbox": []
  },
  "vehicle": {
    "mpg": 25,
    "tank_capacity_gallons": 50,
    "initial_fuel_gallons": 50,
    "max_range_miles": 1250
  },
  "optimization": {
    "feasible": true,
    "total_cost": 42.5,
    "total_gallons_purchased": 12.0,
    "total_fuel_consumed": 28.4,
    "stops": [
      {
        "station": { "id": "8", "name": "Speedway Mansfield", "...": "..." },
        "offset_miles": 420.1,
        "gallons_purchased": 12.0,
        "price_per_gallon": 3.05,
        "cost": 36.6,
        "fuel_after_gallons": 20.0
      }
    ],
    "message": "Optimization completed"
  },
  "stations_near_route": []
}
```

### `GET /api/stations/`

Returns all stations. Optional filters:

- `?lat=40.7&lon=-74.1&radius_miles=50`
- `?min_lat=40&min_lon=-75&max_lat=42&max_lon=-73`

### `GET /api/health/`

Returns `{"status": "ok"}`.

## Optimization algorithm

The optimizer uses a greedy "cheapest reachable station" strategy:

1. If the destination is reachable with current fuel, drive there directly.
2. If a cheaper station is reachable, buy just enough fuel to reach the nearest
   one.
3. If the current station is the cheapest within a full tank's range, fill up
   and drive to the farthest reachable station.
4. If the gap between stations exceeds the vehicle's range, report the trip as
   infeasible.

This runs in `O(n log n)` for sorting plus `O(n)` scanning per leg and is
sufficient for realistic station counts.

## Data

`data/fuel_stations.csv` holds raw station records. Run the geocoding script to
produce `data/fuel_stations_geocoded.csv`, which the service loads:

```bash
python scripts/geocode_stations.py --sleep 1
```

## Tests

```bash
python manage.py test fuel_optimizer
```

## Notes

- Fuel prices are static values from the CSV; wire in a live price feed by
  replacing `fuel_station_service.load_stations`.
- The routing/geocoding clients use `requests`; mock them in tests or swap in
  another provider behind the same service interfaces.
